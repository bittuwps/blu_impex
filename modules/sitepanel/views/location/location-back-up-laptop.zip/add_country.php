<?php $this->load->view("includes/header"); ?>
<div class="page-title">
  <h2><span><?php echo $heading_title; ?></span></h2>
  <a href="javascript:void(0);" onclick="history.back();" class="btn btn-primary pull-right">Cancel</a>
</div>
<div class="page-content-wrap"> 
  <div class="fix"></div>

  <div class="row">

    <div class="col-md-12">

      <div class="panel panel-default">
        <div class="panel-body">
          <?php echo form_open_multipart("", 'class="form-horizontal"'); ?>


          <div class="form-group">
            <label class="col-md-3 col-xs-12 control-label"><span class="required">*</span>Location</label>
            <div class="col-md-6">                                                                                                                                                        
              <input type="text" class="form-control" name="country" value="<?php echo set_value('country') ?>"><?php echo form_error('country'); ?>
            </div>
          </div>
          <div class="form-group">

            <div class="col-md-9">                                                                                                                                                        
              <input type="submit" class="btn bg-red pull-right" name="submit" value="Submit">                                                    
            </div>
          </div>
          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view("includes/footer"); ?>


